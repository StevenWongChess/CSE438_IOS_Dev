import Foundation
import XCTest

public class WelcomeTests : XCTestCase{}
