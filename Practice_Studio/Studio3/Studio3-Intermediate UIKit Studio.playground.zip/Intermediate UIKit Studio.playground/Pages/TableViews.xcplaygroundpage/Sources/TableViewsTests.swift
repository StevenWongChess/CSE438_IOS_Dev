import Foundation
import XCTest

public class TableViewsTests: XCTestCase{}
