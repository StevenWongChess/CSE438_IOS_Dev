import UIKit
import XCTest

public class WelcomeTests: XCTestCase {}
