import XCTest

public class ClosuresTests: XCTestCase {}
