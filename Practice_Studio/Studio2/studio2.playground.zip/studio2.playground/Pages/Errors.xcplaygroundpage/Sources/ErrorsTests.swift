import XCTest

public class ErrorsTests: XCTestCase {}
