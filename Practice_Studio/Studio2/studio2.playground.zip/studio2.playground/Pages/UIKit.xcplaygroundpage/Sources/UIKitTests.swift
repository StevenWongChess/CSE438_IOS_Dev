import XCTest

public class UIKitTests: XCTestCase {}
