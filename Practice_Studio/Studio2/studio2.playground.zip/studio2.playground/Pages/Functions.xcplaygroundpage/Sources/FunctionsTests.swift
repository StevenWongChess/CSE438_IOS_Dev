import XCTest

public class FunctionsTests: XCTestCase {}
