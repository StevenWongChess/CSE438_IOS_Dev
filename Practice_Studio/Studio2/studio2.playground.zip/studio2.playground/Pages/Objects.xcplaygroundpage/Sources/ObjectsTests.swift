import XCTest

public class ObjectsTests: XCTestCase {}
