import XCTest

public class ExtensionsTests: XCTestCase {}
